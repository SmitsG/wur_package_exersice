#' {{{name}}}
#'
#' {{{description}}}.
#'
#' @format A data frame with {{{rows}}} rows and {{{cols}}} variables:
#' \describe{
{{#items}}
#'   \item{ {{name}} }{  {{class}} }
{{/items}}
#' }
#' @source {{{source}}}
"{{{name}}}"
