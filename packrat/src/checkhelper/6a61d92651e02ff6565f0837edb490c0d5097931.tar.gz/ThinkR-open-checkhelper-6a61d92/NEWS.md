# checkhelper 0.0.0.9000

* Print code to add to 'globals.R'
* Extract "no visibles" from notes of rcmdcheck()
* Added a `NEWS.md` file to track changes to the package.
