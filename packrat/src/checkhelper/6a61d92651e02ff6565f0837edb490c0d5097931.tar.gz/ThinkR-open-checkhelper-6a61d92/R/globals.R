globalVariables(
  unique(
    c(
      "is_importfrom", "importfrom_function", "is_global_variable",
      "is_function", "notes", "variable", ".",
      # print_globals:
      "fun", "text",
      # find_missing_tags
      "return_value", "has_export", "has_return", "not_empty_return_value", "has_nord",
      "filename", "id", "rdname_value", "topic"
    )
  )
)
