library(testthat)
library(checkhelper)

test_check("checkhelper")
