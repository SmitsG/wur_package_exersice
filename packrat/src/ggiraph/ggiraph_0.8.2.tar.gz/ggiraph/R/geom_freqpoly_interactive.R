#' @export
#' @rdname geom_histogram_interactive
geom_freqpoly_interactive <- function(...)
  layer_interactive(geom_freqpoly, ...)
