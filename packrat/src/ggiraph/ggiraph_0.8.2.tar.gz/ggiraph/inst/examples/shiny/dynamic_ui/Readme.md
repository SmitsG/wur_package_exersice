This Shiny application shows how to use `renderUI` to dynamically generate 
girafe graphics.

