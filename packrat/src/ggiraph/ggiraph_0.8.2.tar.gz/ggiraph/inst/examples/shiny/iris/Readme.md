This Shiny application demonstrates girafe'selection mecanism. 

Select points on the graphic by clicking on it, selected points will be printed 
in the left panel.

Call to `girafe` specify argument `options` with `opts_selection(type = "single")` 
to force single selection.
