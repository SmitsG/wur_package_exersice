library(testthat)
library(udapi)

test_check("udapi")
