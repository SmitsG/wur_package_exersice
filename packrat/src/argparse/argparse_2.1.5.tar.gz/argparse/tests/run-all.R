library("testthat")

test_check("argparse")
